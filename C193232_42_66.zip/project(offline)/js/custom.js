$('.carousel').carousel({
    interval: 1500

})